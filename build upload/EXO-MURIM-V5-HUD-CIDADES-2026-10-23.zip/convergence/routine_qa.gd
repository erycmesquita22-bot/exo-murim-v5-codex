extends SceneTree
const Game=preload("res://convergence/game.gd")
var w: Node3D
var failures: Array=[]
var checks: Array=[]
var rows: Array=[]
func _initialize():call_deferred("run")
func check(ok: bool,label: String):
	checks.append({"test":label,"pass":ok});print("CHECK ",label," ",ok)
	if not ok:failures.append(label)
func frames(n: int):
	for i in range(n):await physics_frame
func frames_at_hour(hour: int,n: int):
	# Contract fixture: hold one schedule while testing physical route completion.
	# The separate npc_day test advances the uninterrupted default 24h clock.
	for i in range(n):
		w.extension().clock=hour*preload("res://ai_core/world_clock.gd").SECONDS_PER_HOUR
		await physics_frame
		var complete:=i>3
		for actor in w.residents:
			complete=complete and actor.arrived and actor.to_slot==actor.desired_slot(hour)
			if hour==23:complete=complete and actor.sheltered
		if complete:return
func run():
	w=Game.new();w.load_on_start=false;w.world_seed_override=101;w.save_path="user://convergence012_routines.json";root.add_child(w);await process_frame
	w.flow.phase="creator";w.flow.create_character({"name":"Routine QA","race":0,"path":0,"robe":1,"hair":0,"skin":0,"style":0});w.ui.resume()
	for rid in [86,78]:
		check(await w.change_region(rid),"region_"+str(rid))
		var r: Node3D=w.active_region;var cap: Dictionary=r.get_meta("housing_capacity");var used: Dictionary=r.get_meta("housing_occupancy")
		var occupancy_ok:=true;var links_ok:=true;var ids: Dictionary={}
		for id in used:occupancy_ok=occupancy_ok and int(used[id])<=int(cap.get(id,0))
		for actor in w.residents:
			ids[actor.identity.id]=true
			links_ok=links_ok and r.route_points.has(actor.identity.home_slot) and r.route_points.has(actor.identity.work_slot) and not actor.routes.is_empty()
		check(occupancy_ok,"housing_capacity_"+str(rid));check(links_ok,"home_work_links_"+str(rid));check(ids.size()==w.residents.size(),"no_duplicate_"+str(rid))
		var commutes:=0;var completed:=0;var intersections:=0
		w.extension().clock=10*90
		await frames_at_hour(10,11000)
		for actor in w.residents:
			if actor.identity.home_slot!=actor.identity.work_slot:
				commutes+=1
				if actor.arrived and actor.to_slot=="@activity":completed+=1
			var q:=PhysicsShapeQueryParameters3D.new();q.shape=actor.get_child(0).shape;q.collision_mask=4;q.transform=actor.get_child(0).global_transform
			if not w.get_world_3d().direct_space_state.intersect_shape(q).is_empty():intersections+=1
		check(commutes>0 and commutes==completed,"physical_commute_completed_%d:%d/%d"%[rid,completed,commutes])
		check(intersections==0,"no_building_penetration_"+str(rid))
		var resident: Node3D=w.residents[0]
		w.player.position=resident.position+Vector3(0,0,.8);w.player.velocity=Vector3.ZERO;await frames(18)
		w.gate_cooldown=0;w.interaction_cooldown=0;var talks_before: int=resident.talks;w.interact()
		check(resident.talks==talks_before+1,"persistent_interaction_"+str(rid));w.ui.resume()
		w.extension().clock=19*90;await frames_at_hour(19,11000)
		var square:=0
		for actor in w.residents:
			if actor.arrived and actor.to_slot=="@square":square+=1
		check(square==w.residents.size(),"community_arrivals_%d:%d"%[rid,square])
		w.extension().clock=23*90;await frames_at_hour(23,11000)
		var resting:=0
		for actor in w.residents:
			if actor.arrived and actor.sheltered and actor.to_slot==actor.identity.home_slot:resting+=1
		check(resting==w.residents.size(),"night_entry_proxies_%d:%d"%[rid,resting])
		rows.append({"region":rid,"buildings":r.props.size(),"population":w.residents.size(),"commutes":commutes,"completed":completed,"community":square,"resting":resting,"capacity":cap,"occupancy":used})
		w.extension().clock=10*90;await frames(5)
		check(w.save_progress(),"save_routines_"+str(rid))
		var identities: Dictionary=w.journey.data.living_world.npcs.duplicate(true);var count: int=w.residents.size()
		w.return_home();check(await w.change_region(rid),"regional_return_"+str(rid))
		check(w.residents.size()==count and w.journey.data.living_world.npcs==identities,"regional_identity_roundtrip_"+str(rid))
	# Deliberate contact with a temporary obstacle proves recovery without teleporting.
	var actor: Node3D=w.residents[0];actor.arrived=false;actor.route=[actor.position+Vector3(2,0,0)];actor.route_index=0
	var obstacle:=StaticBody3D.new();var collider:=CollisionShape3D.new();var box:=BoxShape3D.new();box.size=Vector3(.3,4,4);collider.shape=box;obstacle.add_child(collider);w.add_child(obstacle);obstacle.position=actor.position+Vector3(.65,1.8,0);obstacle.collision_layer=4
	var old: Vector3=actor.position;await frames(240)
	check(actor.recoveries>0 and actor.position.distance_to(old)<1,"blocked_route_physical_recovery")
	obstacle.free();await frames(160);check(actor.position.distance_to(old)>1,"temporary_obstacle_release")
	check(w.save_progress(),"save_new_process_fixture")
	FileAccess.open("res://convergence/routine_fixture012.json",FileAccess.WRITE).store_string(JSON.stringify({"identities":w.journey.data.living_world.npcs,"actors":w.extension().actors,"current":w.current_region}))
	FileAccess.open("res://convergence/routine_result012.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures,"regions":rows},"\t"))
	print("ROUTINE_RESULT ",JSON.stringify({"checks":checks.size(),"failures":failures}))
	w.simulation_enabled=false;w.audio_fx.shutdown();OS.delay_msec(120);w.free();await process_frame;quit(int(not failures.is_empty()))
