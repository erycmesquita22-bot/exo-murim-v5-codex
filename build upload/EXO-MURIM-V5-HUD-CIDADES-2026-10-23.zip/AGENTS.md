# EXO-MURIM — AGENTS.md PARA CODEX (21/10/2026)

## Identidade e baseline
- Engine: Godot **4.6.2 Standard**, GDScript, renderização **Compatibility**; plataformas alvo Windows/PC (Steam) e Android.
- A raiz deste repositório é o projeto real recuperado da V4. A V4 é fonte de código e arquitetura, **não uma build homologada**.
- Cena principal atual: `res://convergence/game.tscn`. Não aponte para outra sem auditar e executar.
- O arquivo `CODEX_HANDOFF/AGENTS-V4-ORIGINAL.md` mantém as instruções legadas para contexto. Em conflito, siga **este** documento.

## Regras obrigatórias de arquitetura
1. Módulos funcionam como mods: cada módulo é independente, tem manifesto/contratos, dependências e identidades de serviço, e é substituído sempre **integralmente** por sua nova versão; nunca fazer merge incremental sobre o módulo antigo. Remover a árvore ativa antiga em instalação transacional/rollback.
2. Nunca duplicar singleton, autoload, sinal, despachante, serviço, API, classe global ou autoridade de persistência para 'parecer' integrado. Fazer ponte real entre jogo/base e módulos.
3. Módulos novos **não estão incluídos neste pacote**: NPC System 04, Settlement Forge 01 e WorldGenesis V5. Não declarar integração deles antes de receber os ZIPs verificáveis e executar QA.
4. A biblioteca universal e o EXO Core devem manter contratos de autoridade. Não criar substitutos paralelos que contornam integrações.
5. Não preservar compatibilidade com saves legados pré-beta: o usuário autorizou quebrá-la para eliminar resíduos; preservar persistência **da versão atual** após estabilização.
6. Proceduralidade dirigida por conteúdos autorais (bibliotecas, tags, regras, variáveis); evitar repetição e geração vazia.

## Legal e comercial — P0
- O projeto será comercial. Excluir **da build ativa** todos os assets cuja origem própria/original e direitos comerciais não sejam demonstráveis, mesmo se deixar lacunas temporárias. Não reciclar assets externos por adaptação, não confiar apenas no nome de arquivo ou menção vaga de licença.
- Gerar inventário de asset, caminho, origem, licença/documento, hash, decisão (APROVADO / QUARENTENA / REMOVIDO / SUBSTITUIDO). Não classificar como aprovado sem evidência.
- Não usar essa cópia de projeto para lançamento público antes da homologação de direitos.

## QA: verdade por evidência
- Estados: PROPOSTO / IMPLEMENTADO-NAO-TESTADO / TESTE-FALHOU / VALIDADO / HOMOLOGADO / BLOQUEADO. Sem evidência: **NÃO HOMOLOGADO**.
- Para cada correção: (1) artefato verificável; (2) diff; (3) teste real de comportamento; (4) log/captura/reprodução.
- Testes estáticos e sintéticos são preliminares; abrir o projeto não é QA suficiente. Testar criar personagem, gerar mundo, viajar entre regiões, NPCs moverem/interagirem/combaterem, casas/interiores, inventário, economia, save/reload, combate, HUD e estabilidade FPS/Android.
- Verificar parser GDScript em Godot 4.6.2 e regressões. Erros conhecidos históricos incluem `wall_collision` com inferência falha e preload `res://npc_system02/planner.gd`.
- Manter manifesto-mestre para módulos com versão, pasta ZIP e SHA-256, dependências, dono, mudanças, testes, pendências e status.

## Direção visual/experiência
- Voxel puro, skins Minecraft 64x64 classic/slim, roupas e acessórios Murim modulares, cores vivas equilibradas, sem assets de terceiros não autorizados. Fluxo de criação de personagem antes da aventura.
- Não reescrever sistemas validados sem regressão; corrigir e integrar mediante testes reais.

## Ordem de trabalho inicial
1. Validar integridade do repositório extraído; catalogar scripts/cenas/autoloads e dependências; identificar fontes de assets e o que está no caminho crítico da cena principal.
2. Rodar Godot em modo editor/headless para capturar erros de import/parser. Corrigir P0 do boot/persistência e contratos sem misturar versões.
3. Executar roteiros reais de gameplay e atualizar estados por evidência.
4. Após obter os três pacotes faltantes, instalar módulo inteiro com troca atômica e testar leitura em runtime. Não inventar código que deveria estar nos pacotes reais.

## Estado desta cópia V5

Consulte README-CODEX.md e exo_core/modules.json para o estado atual; o texto acima descreve a origem V4. Os três pacotes foram recebidos e integrados nesta cópia. Não reinstale a origem por cima. QA atual: tools/v5/run_qa.py. Evidências históricas não são resultados atuais. Nunca reintroduza binários criativos excluídos. Os recursos novos são gerados por tools/v5/rebuild_generated_art.py e suas especificações. Não crie worktree: cada tarefa cloud já é isolada.

## Atualização do Drive autorizada pelo proprietário

Em 21/10/2026 o usuário confirmou autoria/fontes e autorizou restaurar as paletas FighterArt/EXO e texturas Terrain Forge, prometendo anexar comprovação depois. As 216 paletas e 113 texturas/atlas listadas em docs/v5/drive-owner-art.json estão ativas por essa autorização expressa; não as excluir automaticamente com base na quarentena histórica. Os comprovantes continuam pendentes e não há homologação comercial. As 480 skins legadas continuam fora da build. Leia docs/v5/DRIVE-UPDATE.md e drive-provenance.json antes de importar recursos ou executar geradores. tools/v5/generated_art_specs.json já exclui os recursos restaurados; não substituir novamente sua arte por padrões básicos. Hive usa NPC04, não reinstalar NPC03.

## Bugs reportados em 21/10/2026

Leia docs/v5/BUGFIX-REPORT.md. Os 169 PNG Terrain R3 e seus atlas de quatro linhas substituem a mistura incorreta com R2. Não restaurar shaders de filtragem antigos: todos incluem genesis/terrain_surface.gdshaderinc. Manter a preservação de natural_rock_tex e forge_r3_indices no driver visual. Preservar cotovelos positivos, Wardrobe dos inimigos, passos por superfície, circulação contínua dos figurantes, cor de material na fusão de malhas e árvores ancoradas na interpolação exata do terreno. Rodar qa/v5/reported_bugs.gd além das regressões pertinentes.

## Atualização urbana pelas referências do proprietário

Leia docs/v5/CITY-UPDATE.md. O proprietário pediu expressamente as casas originais da Forja: 14 peças GLB restauradas e registradas em city-forja-assets.json, com declaração do pacote e fontes individuais pendentes. Não substituir essas peças novamente por blocos básicos. Settlement Forge continua dono exclusivo das portas/interiores/colisões; a fachada é somente visual. Preservar os três samplers de máscaras de transição em todos os filtros. Kit não deve impor anisotropia a materiais sem textura: isso os torna pretos no Compatibility 4.6.2. Preservar normais explícitas do gerador Forja e deduplicação dos corredores de multidão. Mudanças urbanas exigem QA world_regions, reported_bugs e drive_updates.

## Mundo/combate Murim

Leia docs/v5/MURIM-UPDATE.md. O perímetro deve incluir protected_sites (todos os limites dos monumentos), e o grafo de aproximação deve excluir desníveis antes da busca. Fauna usa o Regional Ecology existente, orçamentos separados e montagem atômica de matilhas. Não impor o substituto visual genérico sobre anatomia procedural do bestiário. Bestiary propõe táticas; Enemy/PlayerCombat executam ataques. Preservar colisão de projéteis/LOS na camada 4, excluindo os RIDs de atores onde apropriado. Prólogues NPC usam as técnicas do seu arquétipo e a ponte VFX autorizada; não criar singleton/XP/save duplicados. Nomes do catálogo de skills e legacy_bindings do Skill Forge precisam permanecer sincronizados. Rodar fauna_regions, murim_field_combat e world_regions além das regressões.

## Relevo, água e habilidades existentes

Leia docs/v5/RELIEF-WATER-SKILLS.md. A leitura visual de altura fica no shader, com `terrain_reference_height` preservado nos três filtros; não altere só o desenho da malha sem colisão correspondente. UV do rio é transversal/longitudinal; `wading_factor` e `exo_audio.movement_surface` usam o canal físico e respeitam estradas/ponte. `techniques.target_point` deve permanecer na altura do jogador em regiões elevadas. As 16 técnicas legadas jogáveis têm teste nativo individual. As 168 fichas autorais incluem 70 com adaptador e host do jogador condicionado a treino/progressão; 98 não têm adaptador. O host atual recusa NPCs/inimigos. Não declare um cast funcional sem teste de commit/release/efeito. Inimigos comuns usam subconjunto do catálogo existente; moradores NPC04 continuam civis. Rode terrain_water, skill_runtime_sweep, murim_field_combat e as regressões necessárias.
